const express = require("express");
const cors = require("cors");
const fs = require("fs");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.post("/api/bookings", (req, res) => {
  const booking = req.body;

  if (!booking) {
    return res.status(400).json({ error: "Invalid data" });
  }

  fs.readFile("bookings.json", "utf8", (err, data) => {
    const bookings = data ? JSON.parse(data) : [];
    bookings.push(booking);
    fs.writeFile("bookings.json", JSON.stringify(bookings, null, 2), (err) => {
      if (err) {
        return res.status(500).json({ error: "Failed to save booking" });
      }
      res.status(200).json({ message: "Booking saved successfully" });
    });
  });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});